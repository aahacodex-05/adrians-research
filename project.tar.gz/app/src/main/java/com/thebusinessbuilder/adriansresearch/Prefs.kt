package com.thebusinessbuilder.adriansresearch

import android.content.Context

/** Settings saved privately on this phone. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(value) = sp.edit().putString("api_key", value.trim()).apply()

    var model: String
        get() = sp.getString("model", "") ?: ""
        set(value) = sp.edit().putString("model", value.trim()).apply()

    companion object {
        /** Used only if no model has been picked in Settings yet. */
        const val FALLBACK_MODEL = "claude-sonnet-4-5"
    }
}
