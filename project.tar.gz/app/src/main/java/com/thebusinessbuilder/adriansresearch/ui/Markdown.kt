package com.thebusinessbuilder.adriansresearch.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp

/** Small Markdown renderer for Claude's answers: headings, lists, bold, italics, code and links. */
@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val linkColor = MaterialTheme.colorScheme.primary
    val codeBg = MaterialTheme.colorScheme.surfaceVariant
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        var inCode = false
        val codeLines = mutableListOf<String>()
        for (raw in text.lines()) {
            val line = raw.trimEnd()
            if (line.trimStart().startsWith("```")) {
                if (inCode) {
                    Text(
                        codeLines.joinToString("\n"),
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    codeLines.clear()
                }
                inCode = !inCode
                continue
            }
            if (inCode) { codeLines += raw; continue }

            val t = line.trimStart()
            val indent = ((line.length - t.length) / 2).coerceAtMost(4)
            when {
                t.isEmpty() -> Spacer(Modifier.height(4.dp))
                t.matches(Regex("^(-{3,}|\\*{3,}|_{3,})$")) -> HorizontalDivider(Modifier.padding(vertical = 6.dp))
                t.startsWith("#") -> {
                    val level = t.takeWhile { it == '#' }.length
                    val body = t.drop(level).trim()
                    val style = when (level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(inline(body, linkColor, codeBg), style = style, fontWeight = FontWeight.SemiBold)
                }
                t.startsWith("- ") || t.startsWith("* ") || t.startsWith("• ") -> Bullet("•", t.drop(2), indent, linkColor, codeBg)
                Regex("^\\d+[.)] ").containsMatchIn(t) -> {
                    val num = t.substringBefore(' ')
                    Bullet(num, t.substringAfter(' '), indent, linkColor, codeBg)
                }
                t.startsWith(">") -> Text(
                    inline(t.drop(1).trim(), linkColor, codeBg),
                    style = MaterialTheme.typography.bodyLarge,
                    fontStyle = FontStyle.Italic,
                    modifier = Modifier.padding(start = 12.dp),
                )
                else -> Text(inline(t, linkColor, codeBg), style = MaterialTheme.typography.bodyLarge)
            }
        }
        if (inCode && codeLines.isNotEmpty()) {
            Text(codeLines.joinToString("\n"), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun Bullet(marker: String, body: String, indent: Int, linkColor: Color, codeBg: Color) {
    Row(Modifier.padding(start = (indent * 14).dp)) {
        Text(marker, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.width(if (marker.length > 2) 30.dp else 20.dp))
        Text(inline(body.trim(), linkColor, codeBg), style = MaterialTheme.typography.bodyLarge)
    }
}

private val inlineRe = Regex(
    "\\*\\*(.+?)\\*\\*" +                         // 1 bold
        "|\\[([^\\]]+)]\\((https?://[^)\\s]+)\\)" +  // 2,3 link
        "|(https?://[^\\s)<>\\]]+)" +                // 4 bare url
        "|`([^`]+)`" +                              // 5 code
        "|(?<![\\w*])\\*([^*\\n]+?)\\*(?![\\w*])"   // 6 italic
)

fun inline(text: String, linkColor: Color, codeBg: Color): AnnotatedString = buildAnnotatedString {
    val linkStyle = TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))
    var pos = 0
    for (m in inlineRe.findAll(text)) {
        append(text.substring(pos, m.range.first))
        val g = m.groupValues
        when {
            g[1].isNotEmpty() -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(inline(g[1], linkColor, codeBg)) }
            g[2].isNotEmpty() -> withLink(LinkAnnotation.Url(g[3], linkStyle)) { append(g[2]) }
            g[4].isNotEmpty() -> {
                val url = g[4].trimEnd('.', ',', ';', ':')
                withLink(LinkAnnotation.Url(url, linkStyle)) { append(url) }
                append(g[4].removePrefix(url))
            }
            g[5].isNotEmpty() -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(g[5]) }
            g[6].isNotEmpty() -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(g[6]) }
            else -> append(m.value)
        }
        pos = m.range.last + 1
    }
    append(text.substring(pos))
}
