package com.thebusinessbuilder.adriansresearch

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ChatItem {
    data class User(val text: String) : ChatItem()
    data class Assistant(val text: String) : ChatItem()
    data class Tool(val label: String) : ChatItem()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val docStore = DocumentStore(app)
    private val chatFile = File(app.filesDir, "chat.json")

    /** Full Claude conversation (including tool calls). Only changed on the worker thread while busy. */
    private val history = mutableListOf<JSONObject>()

    // ---- Chat state ----
    var items by mutableStateOf(listOf<ChatItem>())
        private set
    var input by mutableStateOf("")
    var busy by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)

    // ---- Documents state ----
    var docs by mutableStateOf(listOf<StoredDoc>())
        private set
    var docMessage by mutableStateOf<String?>(null)
    var importing by mutableStateOf(false)
        private set

    // ---- Settings state ----
    var apiKeyDraft by mutableStateOf(prefs.apiKey)
    var hasKey by mutableStateOf(prefs.apiKey.isNotBlank())
        private set
    var model by mutableStateOf(prefs.model.ifBlank { Prefs.FALLBACK_MODEL })
        private set
    var models by mutableStateOf(listOf<ModelInfo>())
        private set
    var settingsMessage by mutableStateOf<String?>(null)
    var checkingKey by mutableStateOf(false)
        private set

    init {
        loadChat()
        docs = docStore.list()
        if (hasKey) loadModels(quiet = true)
    }

    // ================= Chat =================

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        if (prefs.apiKey.isBlank()) {
            error = "Add your Claude API key in Settings first."
            return
        }
        val rollbackTo = history.size
        history.add(
            JSONObject().put("role", "user")
                .put("content", JSONArray().put(JSONObject().put("type", "text").put("text", text)))
        )
        input = ""
        error = null
        busy = true
        status = "Thinking…"
        items = buildItems()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                runConversation()
                saveChat()
            } catch (e: Exception) {
                while (history.size > rollbackTo) history.removeAt(history.size - 1)
                val msg = when (e) {
                    is ClaudeException -> e.message
                    is java.net.UnknownHostException -> "No internet connection."
                    is java.net.SocketTimeoutException -> "Claude took too long to answer. Try again."
                    else -> "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
                }
                withContext(Dispatchers.Main) {
                    error = msg
                    if (input.isBlank()) input = text
                }
            } finally {
                val newItems = buildItems()
                withContext(Dispatchers.Main) {
                    items = newItems
                    busy = false
                    status = ""
                }
            }
        }
    }

    private suspend fun runConversation() {
        val client = ClaudeClient(prefs.apiKey)
        val modelId = prefs.model.ifBlank { Prefs.FALLBACK_MODEL }

        repeat(MAX_STEPS) { step ->
            if (step > 0) setStatus("Reading what I found…")
            val resp = client.createMessage(modelId, systemPrompt(), requestMessages(), ResearchTools.definitions)
            var content = resp.optJSONArray("content") ?: JSONArray()
            if (content.length() == 0) {
                content = JSONArray().put(JSONObject().put("type", "text").put("text", "(No answer came back. Try asking again.)"))
            }
            history.add(JSONObject().put("role", "assistant").put("content", content))
            publish()

            if (resp.optString("stop_reason") != "tool_use") return

            val results = JSONArray()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") != "tool_use") continue
                val name = block.getString("name")
                val toolInput = block.optJSONObject("input") ?: JSONObject()
                setStatus(ResearchTools.label(name, toolInput) + "…")
                val (out, isError) = ResearchTools.run(name, toolInput)
                val result = JSONObject()
                    .put("type", "tool_result")
                    .put("tool_use_id", block.getString("id"))
                    .put("content", out)
                if (isError) result.put("is_error", true)
                results.put(result)
            }
            history.add(JSONObject().put("role", "user").put("content", results))
        }
        // Too many lookups in a row: close the turn so the conversation stays valid.
        history.add(
            JSONObject().put("role", "assistant").put(
                "content", JSONArray().put(
                    JSONObject().put("type", "text")
                        .put("text", "I stopped after $MAX_STEPS rounds of lookups. Ask me to keep going if you want more.")
                )
            )
        )
    }

    private suspend fun setStatus(s: String) = withContext(Dispatchers.Main) { status = s }

    private suspend fun publish() {
        val newItems = buildItems()
        withContext(Dispatchers.Main) { items = newItems }
    }

    /** History plus the switched-on documents, attached to the first message. */
    private fun requestMessages(): JSONArray {
        val arr = JSONArray()
        val docBlocks = docStore.activeContentBlocks()
        history.forEachIndexed { index, msg ->
            val copy = JSONObject(msg.toString())
            if (index == 0 && docBlocks.isNotEmpty()) {
                val content = JSONArray()
                docBlocks.forEachIndexed { i, b ->
                    // Cache the documents so follow-up questions are cheaper and faster.
                    if (i == docBlocks.lastIndex) b.put("cache_control", JSONObject().put("type", "ephemeral"))
                    content.put(b)
                }
                val orig = copy.getJSONArray("content")
                for (i in 0 until orig.length()) content.put(orig.get(i))
                copy.put("content", content)
            }
            if (index == history.lastIndex) {
                val content = copy.getJSONArray("content")
                if (content.length() > 0) {
                    content.getJSONObject(content.length() - 1)
                        .put("cache_control", JSONObject().put("type", "ephemeral"))
                }
            }
            arr.put(copy)
        }
        return arr
    }

    private fun systemPrompt(): String {
        val today = SimpleDateFormat("MMMM d, yyyy", Locale.US).format(Date())
        val active = docStore.list().filter { it.active }
        val docLine = if (active.isEmpty()) {
            "No documents are attached right now."
        } else {
            "These documents from the user are attached at the start of the conversation: " +
                active.joinToString(", ") { "\"${it.name}\"" } + "."
        }
        return """
            You are Adrians Research, a medical research assistant inside an Android app used by one person.
            You help them understand medical topics, find clinical trials, read current research, and make sense of their own medical documents.
            Today is $today.

            Tools:
            - search_clinical_trials and get_trial_details search ClinicalTrials.gov (live data).
            - search_pubmed searches published research on PubMed.
            Use them whenever a question involves trials, treatments being studied, or what the research says. Search more than once if the first search is too broad or too narrow.

            Rules:
            - Never invent trials, NCT IDs, studies, statistics, or citations. Only cite what the tools returned or what is in the user's documents.
            - Link every trial as https://clinicaltrials.gov/study/NCT######## and every article as https://pubmed.ncbi.nlm.nih.gov/PMID/.
            - When you use the user's documents, say which document (and page, for PDFs) the information came from.
            - Write in plain language and explain medical terms the first time you use them.
            - The answer is read on a phone: use short paragraphs, headings and bullet lists. Do not use tables.
            - For trials, give the key facts: what's being tested, phase, status, who can join, and the nearest locations.
            - You are not a doctor. For decisions about treatment or joining a trial, suggest talking it over with the care team, but don't repeat that warning in every answer.
            - If something sounds like an emergency (for example chest pain, trouble breathing, stroke signs), tell them to call 911 or local emergency services right away.

            $docLine
        """.trimIndent()
    }

    private fun buildItems(): List<ChatItem> {
        val out = mutableListOf<ChatItem>()
        for (msg in history.toList()) {
            val role = msg.optString("role")
            val content = msg.opt("content")
            if (content is String) {
                out += if (role == "user") ChatItem.User(content) else ChatItem.Assistant(content)
                continue
            }
            val arr = content as? JSONArray ?: continue
            val texts = mutableListOf<String>()
            fun flush() {
                if (texts.isNotEmpty()) {
                    val joined = texts.joinToString("").trim()
                    if (joined.isNotEmpty()) {
                        out += if (role == "user") ChatItem.User(joined) else ChatItem.Assistant(joined)
                    }
                    texts.clear()
                }
            }
            for (i in 0 until arr.length()) {
                val b = arr.optJSONObject(i) ?: continue
                when (b.optString("type")) {
                    "text" -> texts += b.optString("text")
                    "tool_use" -> {
                        flush()
                        out += ChatItem.Tool(ResearchTools.label(b.optString("name"), b.optJSONObject("input") ?: JSONObject()))
                    }
                }
            }
            flush()
        }
        return out
    }

    fun newChat() {
        if (busy) return
        history.clear()
        items = emptyList()
        error = null
        chatFile.delete()
    }

    private fun loadChat() {
        if (!chatFile.exists()) return
        runCatching {
            val arr = JSONArray(chatFile.readText())
            for (i in 0 until arr.length()) history.add(arr.getJSONObject(i))
            // A saved chat must end with Claude's turn; drop anything half-finished.
            while (history.isNotEmpty() && history.last().optString("role") != "assistant") {
                history.removeAt(history.size - 1)
            }
        }.onFailure { history.clear() }
        items = buildItems()
    }

    private fun saveChat() {
        val arr = JSONArray()
        history.forEach { arr.put(it) }
        runCatching { chatFile.writeText(arr.toString()) }
    }

    // ================= Documents =================

    fun importDocs(uris: List<Uri>) {
        if (uris.isEmpty()) return
        importing = true
        docMessage = null
        viewModelScope.launch(Dispatchers.IO) {
            val errors = uris.mapNotNull { docStore.importFile(it) }
            val list = docStore.list()
            withContext(Dispatchers.Main) {
                docs = list
                importing = false
                docMessage = when {
                    errors.isNotEmpty() -> errors.joinToString("\n")
                    uris.size == 1 -> "Added. It's switched on, so the chat can read it."
                    else -> "Added ${uris.size} documents."
                }
            }
        }
    }

    fun toggleDoc(id: String, active: Boolean) {
        docStore.setActive(id, active)
        docs = docStore.list()
    }

    fun deleteDoc(id: String) {
        docStore.delete(id)
        docs = docStore.list()
    }

    // ================= Settings =================

    fun saveKey() {
        prefs.apiKey = apiKeyDraft
        hasKey = prefs.apiKey.isNotBlank()
        if (hasKey) loadModels(quiet = false) else settingsMessage = "Key removed."
    }

    fun chooseModel(id: String) {
        prefs.model = id
        model = id
    }

    fun loadModels(quiet: Boolean) {
        val key = prefs.apiKey
        if (key.isBlank()) return
        checkingKey = true
        if (!quiet) settingsMessage = null
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { ClaudeClient(key).listModels() }
            withContext(Dispatchers.Main) {
                checkingKey = false
                result.onSuccess { list ->
                    models = list
                    if (list.isNotEmpty() && list.none { it.id == model }) {
                        val pick = list.firstOrNull { it.id.contains("sonnet") } ?: list.first()
                        chooseModel(pick.id)
                    }
                    if (!quiet) settingsMessage = "Key works. You're ready to chat."
                }.onFailure { e ->
                    if (!quiet) {
                        settingsMessage = (e as? ClaudeException)?.message
                            ?: if (e is java.net.UnknownHostException) "No internet connection." else "Couldn't check the key: ${e.message}"
                    }
                }
            }
        }
    }

    companion object {
        private const val MAX_STEPS = 10
    }
}
