package com.thebusinessbuilder.adriansresearch

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class ClaudeException(message: String) : Exception(message)

data class ModelInfo(val id: String, val name: String)

/** Talks to the Claude Messages API directly from the phone. */
class ClaudeClient(private val apiKey: String) {

    private val base = "https://api.anthropic.com/v1"

    private fun request(path: String): Request.Builder =
        Request.Builder()
            .url("$base$path")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")

    fun createMessage(
        model: String,
        system: String,
        messages: JSONArray,
        tools: JSONArray,
        maxTokens: Int = 4096,
    ): JSONObject {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("tools", tools)
            .put("messages", messages)

        val req = request("/messages")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        Http.client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ClaudeException(friendlyError(resp.code, text))
            return JSONObject(text)
        }
    }

    fun listModels(): List<ModelInfo> {
        val req = request("/models?limit=100").get().build()
        Http.client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ClaudeException(friendlyError(resp.code, text))
            val data = JSONObject(text).optJSONArray("data") ?: JSONArray()
            return (0 until data.length()).map {
                val m = data.getJSONObject(it)
                ModelInfo(m.optString("id"), m.optString("display_name", m.optString("id")))
            }
        }
    }

    private fun friendlyError(code: Int, body: String): String {
        val apiMsg = runCatching {
            JSONObject(body).getJSONObject("error").getString("message")
        }.getOrNull()
        val hint = when (code) {
            401 -> "Your Claude API key was rejected. Check it in Settings."
            403 -> "This API key isn't allowed to do that."
            404 -> "That model wasn't found. Pick a different model in Settings."
            413 -> "Too much was sent at once. Try turning off some documents."
            429 -> "Too many requests or out of credit. Wait a minute, or check your Anthropic billing."
            500, 502, 503, 529 -> "Claude is busy right now. Try again in a moment."
            else -> "Request failed ($code)."
        }
        return if (apiMsg != null) "$hint\n\nDetails: $apiMsg" else hint
    }
}
