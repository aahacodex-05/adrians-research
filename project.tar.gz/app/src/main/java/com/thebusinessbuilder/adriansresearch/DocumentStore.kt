package com.thebusinessbuilder.adriansresearch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class StoredDoc(
    val id: String,
    val name: String,
    val kind: String,      // "pdf", "text", or "image"
    val mediaType: String, // e.g. application/pdf, text/plain, image/jpeg
    val sizeBytes: Long,
    val active: Boolean,   // included in chats when true
)

/** Keeps the user's medical documents in the app's private storage. */
class DocumentStore(private val context: Context) {

    private val dir = File(context.filesDir, "docs").apply { mkdirs() }
    private val indexFile = File(dir, "index.json")

    fun list(): List<StoredDoc> {
        if (!indexFile.exists()) return emptyList()
        val arr = runCatching { JSONArray(indexFile.readText()) }.getOrElse { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            StoredDoc(
                id = o.getString("id"),
                name = o.getString("name"),
                kind = o.getString("kind"),
                mediaType = o.getString("mediaType"),
                sizeBytes = o.optLong("sizeBytes"),
                active = o.optBoolean("active", true),
            )
        }
    }

    private fun save(docs: List<StoredDoc>) {
        val arr = JSONArray()
        docs.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("kind", it.kind)
                    .put("mediaType", it.mediaType).put("sizeBytes", it.sizeBytes).put("active", it.active)
            )
        }
        indexFile.writeText(arr.toString())
    }

    /** Copies a picked file into the app. Returns an error message, or null on success. */
    fun importFile(uri: Uri): String? {
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Document"
        val mime = resolver.getType(uri) ?: guessMime(name)
        val id = UUID.randomUUID().toString()
        val target = File(dir, id)

        val (kind, mediaType) = when {
            mime == "application/pdf" || name.endsWith(".pdf", true) -> "pdf" to "application/pdf"
            mime.startsWith("image/") -> "image" to "image/jpeg"
            mime.startsWith("text/") || mime == "application/json" ||
                listOf(".txt", ".md", ".csv", ".json").any { name.endsWith(it, true) } -> "text" to "text/plain"
            else -> return "\"$name\" isn't supported. Use a PDF, a text file, or a photo."
        }

        try {
            if (kind == "image") {
                // Shrink photos so they fit Claude's limits and upload quickly.
                val bmp = decodeScaled(uri, 1568) ?: return "Couldn't open the image \"$name\"."
                target.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } else {
                resolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { input.copyTo(it) }
                } ?: return "Couldn't open \"$name\"."
            }
        } catch (e: Exception) {
            target.delete()
            return "Couldn't import \"$name\": ${e.message}"
        }

        if (kind == "pdf" && target.length() > 30L * 1024 * 1024) {
            target.delete()
            return "\"$name\" is over 30 MB, which is too big for Claude. Try splitting it."
        }

        save(list() + StoredDoc(id, name, kind, mediaType, target.length(), active = true))
        return null
    }

    fun setActive(id: String, active: Boolean) =
        save(list().map { if (it.id == id) it.copy(active = active) else it })

    fun delete(id: String) {
        File(dir, id).delete()
        save(list().filterNot { it.id == id })
    }

    /** Claude content blocks for every document that's switched on. */
    fun activeContentBlocks(): List<JSONObject> = list().filter { it.active }.mapNotNull { doc ->
        val file = File(dir, doc.id)
        if (!file.exists()) return@mapNotNull null
        when (doc.kind) {
            "pdf" -> JSONObject()
                .put("type", "document")
                .put("title", doc.name)
                .put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "application/pdf")
                        .put("data", Base64.encodeToString(file.readBytes(), Base64.NO_WRAP))
                )
            "text" -> JSONObject()
                .put("type", "document")
                .put("title", doc.name)
                .put(
                    "source", JSONObject()
                        .put("type", "text")
                        .put("media_type", "text/plain")
                        .put("data", file.readText())
                )
            "image" -> JSONObject()
                .put("type", "image")
                .put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", Base64.encodeToString(file.readBytes(), Base64.NO_WRAP))
                )
            else -> null
        }
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val longest = maxOf(bmp.width, bmp.height)
        if (longest <= maxSide) return bmp
        val scale = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
    }

    private fun guessMime(name: String): String = when {
        name.endsWith(".pdf", true) -> "application/pdf"
        name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
        name.endsWith(".png", true) -> "image/png"
        else -> "text/plain"
    }
}
