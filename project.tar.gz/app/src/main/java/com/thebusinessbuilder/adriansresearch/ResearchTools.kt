package com.thebusinessbuilder.adriansresearch

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tools Claude can call: ClinicalTrials.gov (API v2) and PubMed (NCBI E-utilities).
 * Both are free public APIs and need no key.
 */
object ResearchTools {

    val definitions: JSONArray = JSONArray()
        .put(
            JSONObject()
                .put("name", "search_clinical_trials")
                .put(
                    "description",
                    "Search ClinicalTrials.gov for clinical trials. Returns NCT ID, title, status, phase, " +
                        "conditions, interventions, eligibility basics, a short summary and some locations. " +
                        "Use plain medical terms (e.g. 'glioblastoma', 'type 1 diabetes')."
                )
                .put(
                    "input_schema", JSONObject()
                        .put("type", "object")
                        .put(
                            "properties", JSONObject()
                                .put("condition", prop("string", "Disease or condition, e.g. 'non-small cell lung cancer'."))
                                .put("intervention", prop("string", "Optional drug, device or treatment name."))
                                .put("location", prop("string", "Optional city, state, or country, e.g. 'Portland, Oregon'."))
                                .put("other_terms", prop("string", "Optional extra keywords (e.g. a gene mutation like 'EGFR')."))
                                .put(
                                    "status", prop(
                                        "string",
                                        "Which trials to include. Default 'recruiting'."
                                    ).put(
                                        "enum",
                                        JSONArray(listOf("recruiting", "open_or_upcoming", "active", "completed", "any"))
                                    )
                                )
                                .put("max_results", prop("integer", "How many trials to return, 1-20. Default 10."))
                        )
                )
        )
        .put(
            JSONObject()
                .put("name", "get_trial_details")
                .put(
                    "description",
                    "Get full details for one trial on ClinicalTrials.gov: full eligibility criteria, " +
                        "outcomes, arms, contacts and all locations."
                )
                .put(
                    "input_schema", JSONObject()
                        .put("type", "object")
                        .put("properties", JSONObject().put("nct_id", prop("string", "Trial ID like NCT01234567.")))
                        .put("required", JSONArray().put("nct_id"))
                )
        )
        .put(
            JSONObject()
                .put("name", "search_pubmed")
                .put(
                    "description",
                    "Search PubMed for published medical research. Returns titles, journals, dates, PMIDs " +
                        "and abstracts. Supports PubMed query syntax, e.g. 'glioblastoma[tiab] AND immunotherapy'."
                )
                .put(
                    "input_schema", JSONObject()
                        .put("type", "object")
                        .put(
                            "properties", JSONObject()
                                .put("query", prop("string", "PubMed search query."))
                                .put("max_results", prop("integer", "How many articles, 1-10. Default 5."))
                                .put(
                                    "sort", prop("string", "'relevance' (default) or 'date' for newest first.")
                                        .put("enum", JSONArray(listOf("relevance", "date")))
                                )
                                .put("reviews_only", prop("boolean", "Only return review articles / meta-analyses."))
                        )
                        .put("required", JSONArray().put("query"))
                )
        )

    private fun prop(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    /** Short human label shown in the chat while a tool runs. */
    fun label(name: String, input: JSONObject): String = when (name) {
        "search_clinical_trials" -> "Searched clinical trials: " + listOf(
            input.optString("condition"), input.optString("intervention"),
            input.optString("other_terms"), input.optString("location")
        ).filter { it.isNotBlank() }.joinToString(" · ")
        "get_trial_details" -> "Opened trial ${input.optString("nct_id")}"
        "search_pubmed" -> "Searched PubMed: ${input.optString("query")}"
        else -> "Used $name"
    }

    /** Runs a tool and returns text for Claude. Never throws. */
    fun run(name: String, input: JSONObject): Pair<String, Boolean> = try {
        when (name) {
            "search_clinical_trials" -> searchTrials(input) to false
            "get_trial_details" -> trialDetails(input.optString("nct_id")) to false
            "search_pubmed" -> searchPubmed(input) to false
            else -> "Unknown tool: $name" to true
        }
    } catch (e: Exception) {
        "The ${name.replace('_', ' ')} lookup failed: ${e.message ?: e.javaClass.simpleName}" to true
    }

    // ---------------- ClinicalTrials.gov ----------------

    private const val CT = "https://clinicaltrials.gov/api/v2/studies"

    private fun searchTrials(input: JSONObject): String {
        val max = input.optInt("max_results", 10).coerceIn(1, 20)
        val statuses = when (input.optString("status", "recruiting")) {
            "open_or_upcoming" -> "RECRUITING|NOT_YET_RECRUITING|ENROLLING_BY_INVITATION"
            "active" -> "RECRUITING|NOT_YET_RECRUITING|ENROLLING_BY_INVITATION|ACTIVE_NOT_RECRUITING"
            "completed" -> "COMPLETED"
            "any" -> ""
            else -> "RECRUITING"
        }
        val url = CT.toHttpUrl().newBuilder()
            .addQueryParameter("format", "json")
            .addQueryParameter("pageSize", max.toString())
            .addQueryParameter("countTotal", "true")
            .addIfPresent("query.cond", input.optString("condition"))
            .addIfPresent("query.intr", input.optString("intervention"))
            .addIfPresent("query.locn", input.optString("location"))
            .addIfPresent("query.term", input.optString("other_terms"))
            .addIfPresent("filter.overallStatus", statuses)
            .build()

        val json = JSONObject(get(url))
        val studies = json.optJSONArray("studies") ?: JSONArray()
        if (studies.length() == 0) return "No trials found for that search. Try broader terms or a different status."

        val sb = StringBuilder("Total matching trials: ${json.optInt("totalCount", studies.length())}. Showing ${studies.length()}.\n")
        for (i in 0 until studies.length()) {
            val p = studies.getJSONObject(i).optJSONObject("protocolSection") ?: continue
            sb.append("\n---\n").append(summarizeStudy(p, maxLocations = 5, full = false))
        }
        return sb.toString()
    }

    private fun trialDetails(nctIdRaw: String): String {
        val nctId = nctIdRaw.trim().uppercase()
        if (!Regex("NCT\\d{8}").matches(nctId)) return "That doesn't look like a valid NCT ID: $nctIdRaw"
        val url = "$CT/$nctId".toHttpUrl().newBuilder().addQueryParameter("format", "json").build()
        val p = JSONObject(get(url)).optJSONObject("protocolSection") ?: return "No details found for $nctId."
        return summarizeStudy(p, maxLocations = 40, full = true)
    }

    private fun summarizeStudy(p: JSONObject, maxLocations: Int, full: Boolean): String {
        val id = p.optJSONObject("identificationModule")
        val status = p.optJSONObject("statusModule")
        val design = p.optJSONObject("designModule")
        val cond = p.optJSONObject("conditionsModule")
        val arms = p.optJSONObject("armsInterventionsModule")
        val desc = p.optJSONObject("descriptionModule")
        val elig = p.optJSONObject("eligibilityModule")
        val locs = p.optJSONObject("contactsLocationsModule")
        val sponsor = p.optJSONObject("sponsorCollaboratorsModule")?.optJSONObject("leadSponsor")?.optString("name")
        val nct = id?.optString("nctId").orEmpty()

        val sb = StringBuilder()
        sb.append("NCT ID: $nct\n")
        sb.append("Link: https://clinicaltrials.gov/study/$nct\n")
        sb.append("Title: ${id?.optString("officialTitle")?.takeIf { full && it.isNotBlank() } ?: id?.optString("briefTitle")}\n")
        sb.append("Status: ${status?.optString("overallStatus")}\n")
        design?.optJSONArray("phases")?.let { sb.append("Phase: ${it.join(", ").replace("\"", "")}\n") }
        status?.optJSONObject("startDateStruct")?.optString("date")?.let { if (it.isNotBlank()) sb.append("Start: $it\n") }
        status?.optJSONObject("lastUpdatePostDateStruct")?.optString("date")?.let { if (it.isNotBlank()) sb.append("Last updated: $it\n") }
        if (!sponsor.isNullOrBlank()) sb.append("Sponsor: $sponsor\n")
        cond?.optJSONArray("conditions")?.let { sb.append("Conditions: ${strings(it).joinToString(", ")}\n") }

        arms?.optJSONArray("interventions")?.let { arr ->
            val names = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                "${o.optString("name")} (${o.optString("type").lowercase()})"
            }
            sb.append("Interventions: ${names.joinToString("; ")}\n")
        }
        if (elig != null) {
            sb.append("Eligibility: ages ${elig.optString("minimumAge", "any")} to ${elig.optString("maximumAge", "any")}, sex: ${elig.optString("sex", "ALL")}, healthy volunteers: ${elig.optBoolean("healthyVolunteers", false)}\n")
        }
        desc?.optString("briefSummary")?.takeIf { it.isNotBlank() }?.let {
            sb.append("Summary: ${if (full) it else it.take(600)}\n")
        }

        if (full) {
            elig?.optString("eligibilityCriteria")?.takeIf { it.isNotBlank() }?.let {
                sb.append("\nEligibility criteria:\n${it.take(6000)}\n")
            }
            p.optJSONObject("outcomesModule")?.optJSONArray("primaryOutcomes")?.let { arr ->
                sb.append("\nPrimary outcomes:\n")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    sb.append("- ${o.optString("measure")} (${o.optString("timeFrame")})\n")
                }
            }
            arms?.optJSONArray("armGroups")?.let { arr ->
                sb.append("\nArms:\n")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    sb.append("- ${o.optString("label")}: ${o.optString("description").take(300)}\n")
                }
            }
            locs?.optJSONArray("centralContacts")?.let { arr ->
                sb.append("\nCentral contacts:\n")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    sb.append("- ${o.optString("name")} ${o.optString("phone")} ${o.optString("email")}\n".replace("  ", " "))
                }
            }
        }

        locs?.optJSONArray("locations")?.let { arr ->
            if (arr.length() > 0) {
                sb.append("Locations (${arr.length()} total):\n")
                for (i in 0 until minOf(arr.length(), maxLocations)) {
                    val o = arr.getJSONObject(i)
                    val place = listOf(o.optString("facility"), o.optString("city"), o.optString("state"), o.optString("country"))
                        .filter { it.isNotBlank() }.joinToString(", ")
                    val st = o.optString("status").takeIf { it.isNotBlank() }?.let { " [$it]" } ?: ""
                    sb.append("- $place$st\n")
                }
            }
        }
        return sb.toString()
    }

    // ---------------- PubMed ----------------

    private const val EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

    private fun searchPubmed(input: JSONObject): String {
        val max = input.optInt("max_results", 5).coerceIn(1, 10)
        var term = input.optString("query").trim()
        if (term.isBlank()) return "Empty PubMed query."
        if (input.optBoolean("reviews_only", false)) {
            term = "($term) AND (review[pt] OR systematic review[pt] OR meta-analysis[pt])"
        }
        val searchUrl = "$EUTILS/esearch.fcgi".toHttpUrl().newBuilder()
            .addQueryParameter("db", "pubmed")
            .addQueryParameter("term", term)
            .addQueryParameter("retmode", "json")
            .addQueryParameter("retmax", max.toString())
            .addQueryParameter("sort", if (input.optString("sort") == "date") "pub_date" else "relevance")
            .addQueryParameter("tool", "adrians-research")
            .build()
        val result = JSONObject(get(searchUrl)).getJSONObject("esearchresult")
        val ids = strings(result.optJSONArray("idlist") ?: JSONArray())
        if (ids.isEmpty()) return "No PubMed articles found for: $term"

        val summaryUrl = "$EUTILS/esummary.fcgi".toHttpUrl().newBuilder()
            .addQueryParameter("db", "pubmed")
            .addQueryParameter("id", ids.joinToString(","))
            .addQueryParameter("retmode", "json")
            .addQueryParameter("tool", "adrians-research")
            .build()
        val summaries = JSONObject(get(summaryUrl)).optJSONObject("result") ?: JSONObject()

        val abstracts = runCatching { fetchAbstracts(ids) }.getOrDefault(emptyMap())

        val sb = StringBuilder("PubMed results: ${result.optString("count")} total, showing ${ids.size}.\n")
        for (pmid in ids) {
            val s = summaries.optJSONObject(pmid) ?: continue
            val authors = s.optJSONArray("authors")?.let { arr ->
                val names = (0 until arr.length()).map { arr.getJSONObject(it).optString("name") }
                if (names.size > 3) names.take(3).joinToString(", ") + " et al." else names.joinToString(", ")
            }.orEmpty()
            val types = s.optJSONArray("pubtype")?.let { strings(it).joinToString(", ") }.orEmpty()
            sb.append("\n---\nPMID: $pmid\n")
            sb.append("Link: https://pubmed.ncbi.nlm.nih.gov/$pmid/\n")
            sb.append("Title: ${s.optString("title")}\n")
            sb.append("Journal: ${s.optString("fulljournalname", s.optString("source"))}, ${s.optString("pubdate")}\n")
            if (authors.isNotBlank()) sb.append("Authors: $authors\n")
            if (types.isNotBlank()) sb.append("Type: $types\n")
            abstracts[pmid]?.let { sb.append("Abstract: ${it.take(2500)}\n") }
        }
        return sb.toString()
    }

    /** Pulls abstracts as XML and extracts the AbstractText for each PMID. */
    private fun fetchAbstracts(ids: List<String>): Map<String, String> {
        val url = "$EUTILS/efetch.fcgi".toHttpUrl().newBuilder()
            .addQueryParameter("db", "pubmed")
            .addQueryParameter("id", ids.joinToString(","))
            .addQueryParameter("retmode", "xml")
            .addQueryParameter("tool", "adrians-research")
            .build()
        val xml = get(url)
        val out = mutableMapOf<String, String>()
        val articleRe = Regex("<PubmedArticle>(.*?)</PubmedArticle>", RegexOption.DOT_MATCHES_ALL)
        val pmidRe = Regex("<PMID[^>]*>(\\d+)</PMID>")
        val absRe = Regex("<AbstractText([^>]*)>(.*?)</AbstractText>", RegexOption.DOT_MATCHES_ALL)
        val labelRe = Regex("Label=\"([^\"]+)\"")
        for (m in articleRe.findAll(xml)) {
            val body = m.groupValues[1]
            val pmid = pmidRe.find(body)?.groupValues?.get(1) ?: continue
            val parts = absRe.findAll(body).map { a ->
                val label = labelRe.find(a.groupValues[1])?.groupValues?.get(1)
                val text = unescapeXml(a.groupValues[2].replace(Regex("<[^>]+>"), ""))
                if (label != null) "$label: $text" else text
            }.toList()
            if (parts.isNotEmpty()) out[pmid] = parts.joinToString(" ")
        }
        return out
    }

    private fun unescapeXml(s: String) = s
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")

    // ---------------- helpers ----------------

    private fun HttpUrl.Builder.addIfPresent(name: String, value: String?): HttpUrl.Builder {
        if (!value.isNullOrBlank()) addQueryParameter(name, value.trim())
        return this
    }

    private fun strings(arr: JSONArray) = (0 until arr.length()).map { arr.optString(it) }

    private fun get(url: HttpUrl): String {
        val req = Request.Builder().url(url).header("Accept", "application/json, text/xml").get().build()
        Http.client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}: ${text.take(300)}")
            return text
        }
    }
}
