package com.thebusinessbuilder.adriansresearch.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.thebusinessbuilder.adriansresearch.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var showKey by remember { mutableStateOf(false) }
    val linkColor = MaterialTheme.colorScheme.primary
    val codeBg = MaterialTheme.colorScheme.surfaceVariant

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Settings", fontWeight = FontWeight.SemiBold) })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Claude API key", style = MaterialTheme.typography.titleMedium)
            Text(
                inline("Get one at [console.anthropic.com](https://console.anthropic.com/settings/keys), then paste it here. It's saved only on this phone.", linkColor, codeBg),
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedTextField(
                value = vm.apiKeyDraft,
                onValueChange = { vm.apiKeyDraft = it },
                label = { Text("API key (starts with sk-ant-)") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (showKey) "Hide key" else "Show key")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.saveKey() }, enabled = !vm.checkingKey) { Text("Save key") }
                Spacer(Modifier.size(12.dp))
                if (vm.checkingKey) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            }
            vm.settingsMessage?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }

            HorizontalDivider(Modifier.padding(vertical = 4.dp))

            Text("Claude model", style = MaterialTheme.typography.titleMedium)
            Text(
                "Sonnet is a good balance of quality, speed and cost. Opus is the most capable but costs more. Haiku is fastest and cheapest.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (vm.models.isEmpty()) {
                Text("Current: ${vm.model}", style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { vm.loadModels(quiet = false) }, enabled = vm.hasKey && !vm.checkingKey) {
                    Text("Load available models")
                }
            } else {
                Column {
                    vm.models.forEach { m ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .selectable(selected = m.id == vm.model, onClick = { vm.chooseModel(m.id) }, role = Role.RadioButton)
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = m.id == vm.model, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Column {
                                Text(m.name, style = MaterialTheme.typography.bodyLarge)
                                Text(m.id, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 4.dp))

            Text("About", style = MaterialTheme.typography.titleMedium)
            Text(
                inline(
                    "Trial data comes live from [ClinicalTrials.gov](https://clinicaltrials.gov). Research articles come from [PubMed](https://pubmed.ncbi.nlm.nih.gov). Answers are written by Claude, which can make mistakes, so check important details at the source.\n\nThis app is for research and learning. It isn't medical advice. Talk with your care team before making treatment decisions.",
                    linkColor, codeBg,
                ),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text("Version 1.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(24.dp))
        }
    }
}
