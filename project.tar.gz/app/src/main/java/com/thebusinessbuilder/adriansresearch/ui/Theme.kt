package com.thebusinessbuilder.adriansresearch.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val Light = lightColorScheme(
    primary = Color(0xFF0E5E6F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBF0),
    onPrimaryContainer = Color(0xFF00313A),
    secondary = Color(0xFF4A6268),
    secondaryContainer = Color(0xFFCDE7ED),
    onSecondaryContainer = Color(0xFF051F24),
    background = Color(0xFFF7FAFB),
    surface = Color(0xFFF7FAFB),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF84D2E2),
    onPrimary = Color(0xFF00363F),
    primaryContainer = Color(0xFF004E5B),
    onPrimaryContainer = Color(0xFFCDEBF0),
    secondary = Color(0xFFB1CBD1),
    secondaryContainer = Color(0xFF334A50),
    onSecondaryContainer = Color(0xFFCDE7ED),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        dark -> Dark
        else -> Light
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
